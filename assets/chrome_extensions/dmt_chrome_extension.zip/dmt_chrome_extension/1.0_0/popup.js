window.addEventListener('load', init, false);

/* =================================================== */
/* === GENERAL UTILITIES ============================= */
/* =================================================== */

function $(selector, parent) {
  // Get element(s) shortcut
  if (selector.nodeType) {
    // if it an element, return it
    return selector;
  }

  // Set the parent element to search within
  if (!parent) {
    parent = document;
  } else if (!parent.nodeType) {
    // parent given is an id
    parent = $(parent);
  }

  switch (selector.charAt(0)) {
    case '.':
      return parent.getElementsByClassName(selector.substr(1))[0];
      break;
    case '#':
      return parent.getElementById(selector.substr(1));
      break;
    case ',':
      return parent.getElementsByClassName(selector.substr(1));
      break;
    case '>':
      return parent.getElementsByTagName(selector.substr(1));
      break;
    default:
      return parent.getElementsByTagName(selector)[0];
      break;
  }
}

// function checkForClass(nameOfClass, element) {
//   if (typeof element == 'string') {
//     element = $(element);
//   }
//   if (element && element.className != '') {
//     return new RegExp('\\b' + nameOfClass + '\\b').test(element.className);
//   } else {
//     return false;
//   }
// }
// function addClass(nameOfClass, element) {
//   if (typeof element == 'string') {
//     element = $(element);
//   }
//   if (element && !checkForClass(nameOfClass, element)) {
//     element.className += (element.className ? ' ' : '') + nameOfClass;
//   }
// }
// function removeClass(nameOfClass, element) {
//   if (typeof element == 'string') {
//     element = $(element);
//   }
//   if (element && checkForClass(nameOfClass, element)) {
//     element.className = element.className.replace(element.className.indexOf(' ' + nameOfClass) >= 0 ? ' ' + nameOfClass : nameOfClass, '');
//   }
// }
// function toggleClass(nameOfClass, element) {
//   if (typeof element == 'string') {
//     element = $(element);
//   }
//   if (element && checkForClass(nameOfClass, element)) {
//     removeClass(nameOfClass, element);
//   } else {
//     addClass(nameOfClass, element);
//   }
// }

// INIT
function init() {
  $('#open').addEventListener(
    'click',
    function() {
      chrome.tabs.create({ url: 'http://localhost:7777' });
    },
    false
  );
}
